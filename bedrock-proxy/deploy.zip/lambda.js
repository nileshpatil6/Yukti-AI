const BEDROCK_BASE_URL = 'https://bedrock-mantle.eu-north-1.api.aws/v1';

exports.handler = async (event) => {
    const BEDROCK_API_KEY = process.env.BEDROCK_API_KEY || '';

    // Universal CORS headers
    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With',
    };

    // 1. Handle CORS Preflight (OPTIONS request) natively
    if (event.requestContext?.http?.method === 'OPTIONS' || event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers,
            body: ''
        };
    }

    // 2. Health check catch
    if (event.rawPath && event.rawPath.endsWith('/health')) {
        return { statusCode: 200, headers, body: JSON.stringify({ status: 'ok' }) };
    }

    // 3. Proxy everything else to Bedrock
    try {
        let requestBody = event.body || '{}';
        if (event.isBase64Encoded && event.body) {
            requestBody = Buffer.from(event.body, 'base64').toString('utf-8');
        }

        const response = await fetch(`${BEDROCK_BASE_URL}/chat/completions`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${BEDROCK_API_KEY}`,
                'Content-Type': 'application/json',
            },
            body: requestBody,
        });

        const responseText = await response.text();
        let data;

        try {
            data = JSON.parse(responseText);
        } catch (e) {
            // If Bedrock sent something like an HTML error page, catch it and return safely
            return {
                statusCode: response.status,
                headers,
                body: JSON.stringify({ error: 'Failed to parse Bedrock response', rawResponse: responseText })
            };
        }

        return {
            statusCode: response.status,
            headers,
            body: JSON.stringify(data),
        };
    } catch (error) {
        console.error('Proxy error:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
                error: 'Lambda Proxy explicitly failed',
                details: String(error),
                stack: error.stack
            }),
        };
    }
};
